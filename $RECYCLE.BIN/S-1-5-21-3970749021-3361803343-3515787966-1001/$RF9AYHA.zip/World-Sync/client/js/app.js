const els = {
  connectionBadge: document.getElementById('connectionBadge'),
  worldName: document.getElementById('worldName'),
  worldPath: document.getElementById('worldPath'),
  lastUpload: document.getElementById('lastUpload'),
  refreshBtn: document.getElementById('refreshBtn'),
  uploadBtn: document.getElementById('uploadBtn'),
  downloadBtn: document.getElementById('downloadBtn'),
  progressWrap: document.getElementById('progressWrap'),
  progressLabel: document.getElementById('progressLabel'),
  toastContainer: document.getElementById('toastContainer')
};

let statusTimer;

function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  els.toastContainer.appendChild(toast);
  setTimeout(() => toast.remove(), 5000);
}

function setProgress(visible, label = 'Working...') {
  els.progressWrap.classList.toggle('hidden', !visible);
  els.progressLabel.textContent = label;
}

function setButtonsDisabled(disabled) {
  [els.refreshBtn, els.uploadBtn, els.downloadBtn].forEach((btn) => {
    btn.disabled = disabled;
  });
}

function formatDate(iso) {
  if (!iso) return 'Never';
  return new Date(iso).toLocaleString();
}

function formatMb(bytes) {
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

async function apiCall(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || data.error || `Request failed (${res.status})`);
  }
  return data;
}

async function refreshStatus({ quiet = false } = {}) {
  try {
    const status = await apiCall('/api/status');
    els.connectionBadge.textContent = status.connected ? 'Connected' : 'Disconnected';
    els.connectionBadge.className = `badge ${status.connected ? 'badge-connected' : 'badge-disconnected'}`;
    els.worldName.textContent = status.selectedWorld || 'None';
    els.worldPath.textContent = status.path || 'Not set';
    els.lastUpload.textContent = formatDate(status.lastUpload);
  } catch (err) {
    els.connectionBadge.textContent = 'Error';
    els.connectionBadge.className = 'badge badge-disconnected';
    if (!quiet) showToast(err.message, 'error');
  }
}

async function runSyncAction({ label, request, onSuccess }) {
  window.clearInterval(statusTimer);
  setButtonsDisabled(true);
  setProgress(true, label);
  try {
    const result = await request();
    onSuccess(result);
    await refreshStatus({ quiet: true });
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    setProgress(false);
    setButtonsDisabled(false);
    statusTimer = window.setInterval(() => refreshStatus({ quiet: true }), 15000);
  }
}

function uploadWorld() {
  runSyncAction({
    label: 'Compressing and uploading...',
    request: () => apiCall('/api/upload', { method: 'POST' }),
    onSuccess: (result) => {
      showToast(`Uploaded ${result.worldName} (${formatMb(result.sizeBytes)})`);
    }
  });
}

function downloadWorld() {
  const confirmed = window.confirm('This will overwrite files in the configured world folder. Continue?');
  if (!confirmed) return;

  runSyncAction({
    label: 'Downloading and restoring...',
    request: () => apiCall('/api/download', { method: 'POST' }),
    onSuccess: (result) => {
      showToast(`Restored ${result.worldName} from ${formatDate(result.uploadedAt)}`);
    }
  });
}

els.refreshBtn.addEventListener('click', () => refreshStatus());
els.uploadBtn.addEventListener('click', uploadWorld);
els.downloadBtn.addEventListener('click', downloadWorld);

refreshStatus({ quiet: true });
statusTimer = window.setInterval(() => refreshStatus({ quiet: true }), 15000);
