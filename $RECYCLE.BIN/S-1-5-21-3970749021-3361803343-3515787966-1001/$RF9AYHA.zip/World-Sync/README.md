# Minecraft World Sync

A local tool to back up a Minecraft world to MongoDB Atlas and restore it later.
Runs entirely on your own machine - no accounts, no auth, no multiplayer sync.

## Installation

1. Install [Node.js 18+](https://nodejs.org).
2. Clone or download this project.
3. Run:
   ```bash
   npm install
   ```

## MongoDB Atlas Setup

1. Create a free cluster at https://www.mongodb.com/cloud/atlas.
2. Create a database user (username + password).
3. Under Network Access, allow your current IP address.
4. Copy the connection string (Drivers -> Node.js).

## Environment Variables

Copy `.env.example` to `.env` and fill in your values:

```bash
cp .env.example .env
```

```ini
MONGODB_URI=mongodb+srv://<user>:<password>@<cluster>.mongodb.net/minecraft_world_sync?retryWrites=true&w=majority
PORT=3000
WORLD_PATH=/absolute/path/to/your/Minecraft/world
```

## Running Locally

```bash
npm start
```

Then open http://localhost:3000 in your browser.

## Running With Docker

```bash
docker build -t minecraft-world-sync .
docker run --rm -p 3000:3000 --env-file .env -v "${PWD}/config.json:/app/config.json" minecraft-world-sync
```

Or with Compose:

```bash
docker compose up --build
```

Important: the native folder-picker flow is not usable inside a container because the dialog must run on the host desktop session. Docker works well for the upload/download server, but selecting the folder should be done from a non-containerized launch if you need that exact OS dialog behavior.

## Usage

1. Set `WORLD_PATH` in `.env` to your absolute world folder path.
2. Click **Upload World** to compress and back it up to MongoDB Atlas.
3. On another machine, set the same `WORLD_PATH` and click **Download Latest Backup** to restore it.

## Folder Structure

```text
minecraft-world-sync/
├── server/
│   ├── routes/
│   ├── controllers/
│   ├── services/
│   ├── models/
│   ├── config/
│   ├── app.js
│   └── server.js
├── client/
│   ├── css/
│   ├── js/
│   └── index.html
├── config.json
├── package.json
└── README.md
```

## API Documentation

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/status` | Returns connection state, selected world, path, last upload time |
| POST | `/api/select-folder` | Opens native folder dialog, saves chosen path to `config.json` |
| POST | `/api/upload` | Compresses the configured world and uploads it to MongoDB |
| POST | `/api/download` | Downloads the latest backup and restores it, replacing the local folder |

## Storage Strategy

Backups under about 14MB are stored directly as a document. Larger backups are automatically
streamed into GridFS instead.

## Troubleshooting

- `"Folder dialog failed" on Linux` - install `zenity`: `sudo apt install zenity` or your distro equivalent.
- `WORLD_PATH` set in `.env` - the server uses that path first, so the folder picker becomes optional.
- `"Database is not connected"` - check your `MONGODB_URI`, and confirm your IP is allowlisted in Atlas Network Access.
- `"Configured world folder no longer exists on disk"` - the saved path was moved or deleted; update `WORLD_PATH` or click Browse Folder again.
- `Upload` fails on very large worlds - check your Atlas tier's storage limits; GridFS handles the document limit automatically, but total cluster storage still applies.
- `multer` dependency - included per the original spec for potential direct browser-upload support, but the primary flow compresses and uploads server-side.
