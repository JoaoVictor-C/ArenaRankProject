const fs = require('fs-extra');
const mongoose = require('mongoose');
// Use the MongoDB driver bundled with mongoose so BSON types (ObjectId, etc.)
// come from a single bson version. Requiring the standalone `mongodb` package
// mixes bson 7.x with mongoose's bson 6.x and throws "Unsupported BSON version".
const { GridFSBucket } = mongoose.mongo;
const WorldBackup = require('../models/WorldBackup');

const INLINE_SIZE_LIMIT = 14 * 1024 * 1024;

function getBucket() {
  return new GridFSBucket(mongoose.connection.db, { bucketName: 'worldBackups' });
}

async function uploadBackup(worldName, zipFilePath) {
  const stats = await fs.stat(zipFilePath);

  if (stats.size <= INLINE_SIZE_LIMIT) {
    const buffer = await fs.readFile(zipFilePath);
    const doc = await WorldBackup.create({
      worldName,
      storageType: 'inline',
      fileSize: stats.size,
      zipData: buffer
    });
    return doc;
  }

  const bucket = getBucket();
  const gridFileId = await new Promise((resolve, reject) => {
    const uploadStream = bucket.openUploadStream(`${worldName}.zip`);
    fs.createReadStream(zipFilePath)
      .pipe(uploadStream)
      .on('error', reject)
      .on('finish', () => resolve(uploadStream.id));
  });

  const doc = await WorldBackup.create({
    worldName,
    storageType: 'gridfs',
    fileSize: stats.size,
    gridfsFileId: gridFileId
  });
  return doc;
}

async function getLatestBackup(worldName) {
  return WorldBackup.findOne({
    worldName,
    fileSize: { $gt: 1024 }
  }).sort({ uploadedAt: -1 });
}

async function downloadBackupToFile(doc, destZipPath) {
  if (doc.storageType === 'inline') {
    await fs.writeFile(destZipPath, doc.zipData);
    return destZipPath;
  }

  const bucket = getBucket();
  await new Promise((resolve, reject) => {
    const downloadStream = bucket.openDownloadStream(doc.gridfsFileId);
    const writeStream = fs.createWriteStream(destZipPath);
    downloadStream.on('error', reject);
    writeStream.on('error', reject);
    writeStream.on('finish', resolve);
    downloadStream.pipe(writeStream);
  });
  return destZipPath;
}

module.exports = { uploadBackup, getLatestBackup, downloadBackupToFile };
