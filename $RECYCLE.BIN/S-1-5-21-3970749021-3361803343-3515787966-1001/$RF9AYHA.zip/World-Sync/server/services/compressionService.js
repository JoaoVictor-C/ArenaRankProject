const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const unzipper = require('unzipper');

async function compressFolder(sourceDir, outZipPath) {
  const exists = await fs.pathExists(sourceDir);
  if (!exists) {
    throw new Error(`World folder not found: ${sourceDir}`);
  }

  await fs.ensureDir(path.dirname(outZipPath));

  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outZipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => resolve(outZipPath));
    archive.on('error', (err) => reject(new Error('Compression failed: ' + err.message)));
    output.on('error', (err) => reject(new Error('Compression write failed: ' + err.message)));
    archive.on('warning', (warn) => {
      if (warn.code === 'ENOENT' || warn.code === 'EIO') {
        console.warn('Skipping unreadable file during compression:', warn.message);
        return;
      }
      reject(new Error('Compression warning: ' + warn.message));
    });

    archive.pipe(output);
    const worldName = path.basename(sourceDir);
    archive.directory(sourceDir, worldName, (entry) => {
      const baseName = path.basename(entry.name);
      if (baseName === 'session.lock') return false;
      if (baseName.endsWith('.gz')) return false;
      return entry;
    });
    archive.finalize();
  });
}

async function extractZip(zipPath, destWorldDir, worldName) {
  const exists = await fs.pathExists(zipPath);
  if (!exists) {
    throw new Error(`Backup ZIP not found: ${zipPath}`);
  }

  const tempExtractDir = path.join(path.dirname(zipPath), `restore-${Date.now()}`);

  await fs.ensureDir(tempExtractDir);

  try {
    await new Promise((resolve, reject) => {
      fs.createReadStream(zipPath)
        .pipe(unzipper.Extract({ path: tempExtractDir }))
        .on('close', resolve)
        .on('error', (err) => reject(new Error('Extraction failed: ' + err.message)));
    });

    const nestedWorldDir = path.join(tempExtractDir, worldName);
    const extractedWorldDir = (await fs.pathExists(nestedWorldDir)) ? nestedWorldDir : tempExtractDir;

    await fs.ensureDir(destWorldDir);
    await fs.copy(extractedWorldDir, destWorldDir, {
      overwrite: true,
      errorOnExist: false
    });

    return destWorldDir;
  } finally {
    await fs.remove(tempExtractDir).catch(() => {});
  }
}

module.exports = { compressFolder, extractZip };
