const { execFile } = require('child_process');
const os = require('os');

function pickFolder() {
  const platform = os.platform();

  return new Promise((resolve, reject) => {
    if (platform === 'win32') {
      const psScript = `
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = "Select your Minecraft world folder"
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
          Write-Output $dialog.SelectedPath
        }
      `;
      execFile(
        'powershell.exe',
        ['-NoProfile', '-NonInteractive', '-Command', psScript],
        { windowsHide: true },
        (err, stdout) => {
          if (err) return reject(new Error('Folder dialog failed: ' + err.message));
          const result = stdout.trim();
          resolve(result.length > 0 ? result : null);
        }
      );
    } else if (platform === 'darwin') {
      execFile(
        'osascript',
        ['-e', 'POSIX path of (choose folder with prompt "Select your Minecraft world folder")'],
        (err, stdout) => {
          if (err) {
            if (err.message.includes('User canceled')) return resolve(null);
            return reject(new Error('Folder dialog failed: ' + err.message));
          }
          resolve(stdout.trim() || null);
        }
      );
    } else {
      execFile(
        'zenity',
        ['--file-selection', '--directory', '--title=Select your Minecraft world folder'],
        (err, stdout) => {
          if (err) {
            if (err.code === 1) return resolve(null);
            return reject(new Error('Folder dialog failed. Is "zenity" installed? (' + err.message + ')'));
          }
          resolve(stdout.trim() || null);
        }
      );
    }
  });
}

module.exports = { pickFolder };
