require('dotenv').config();
const app = require('./app');
const { connectDB } = require('./config/db');

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    await connectDB();
    app.listen(PORT, () => {
      console.log(`Minecraft World Sync running at http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err.message);
    app.listen(PORT, () => {
      console.log(`Server running WITHOUT database connection on port ${PORT}`);
    });
  }
}

start();
