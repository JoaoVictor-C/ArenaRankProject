const express = require('express');
const path = require('path');
const apiRoutes = require('./routes/api');

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'client')));
app.use('/api', apiRoutes);

app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error', message: err.message });
});

module.exports = app;
