const mongoose = require('mongoose');

const worldBackupSchema = new mongoose.Schema({
  worldName: { type: String, required: true, index: true },
  uploadedAt: { type: Date, default: Date.now, index: true },
  storageType: { type: String, enum: ['inline', 'gridfs'], required: true },
  fileSize: { type: Number, required: true },
  zipData: { type: Buffer, default: undefined },
  gridfsFileId: { type: mongoose.Schema.Types.ObjectId, default: undefined }
});

module.exports = mongoose.model('WorldBackup', worldBackupSchema);
