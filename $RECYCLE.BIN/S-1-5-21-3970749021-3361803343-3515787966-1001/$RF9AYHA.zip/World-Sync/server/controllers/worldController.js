const path = require('path');
const fs = require('fs-extra');
const os = require('os');
const { readConfig, writeConfig } = require('../config/configStore');
const { pickFolder } = require('../services/folderPickerService');
const { compressFolder, extractZip } = require('../services/compressionService');
const { uploadBackup, getLatestBackup, downloadBackupToFile } = require('../services/storageService');
const { getConnectionStatus } = require('../config/db');

const TEMP_DIR = path.join(os.tmpdir(), 'minecraft-world-sync');

async function getStatus(req, res) {
  try {
    const config = await readConfig();
    const worldName = config.worldPath ? path.basename(config.worldPath) : null;

    let lastUpload = null;
    if (worldName && getConnectionStatus()) {
      const latest = await getLatestBackup(worldName);
      if (latest) lastUpload = latest.uploadedAt;
    }

    res.json({
      connected: getConnectionStatus(),
      selectedWorld: worldName,
      path: config.worldPath || null,
      lastUpload
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load status', message: err.message });
  }
}

async function selectFolder(req, res) {
  try {
    if (process.env.WORLD_PATH) {
      return res.status(400).json({
        error: 'WORLD_PATH is set in .env; update that value instead of using the folder picker'
      });
    }

    const chosenPath = await pickFolder();
    if (!chosenPath) {
      return res.status(200).json({ cancelled: true });
    }

    const isDir = (await fs.pathExists(chosenPath)) && (await fs.stat(chosenPath)).isDirectory();
    if (!isDir) {
      return res.status(400).json({ error: 'Selected path is not a valid folder' });
    }

    const config = await writeConfig({ worldPath: chosenPath });
    res.json({ cancelled: false, worldPath: config.worldPath });
  } catch (err) {
    res.status(500).json({ error: 'Failed to select folder', message: err.message });
  }
}

async function uploadWorld(req, res) {
  let zipPath;
  try {
    const config = await readConfig();
    if (!config.worldPath) {
      return res.status(400).json({ error: 'No world folder selected yet' });
    }

    const worldExists = await fs.pathExists(config.worldPath);
    if (!worldExists) {
      return res.status(400).json({ error: 'Configured world folder no longer exists on disk' });
    }

    const levelDatExists = await fs.pathExists(path.join(config.worldPath, 'level.dat'));
    if (!levelDatExists) {
      return res.status(400).json({
        error: 'Configured world folder does not look like a Minecraft save. Missing level.dat.'
      });
    }

    if (!getConnectionStatus()) {
      return res.status(503).json({ error: 'Database is not connected' });
    }

    const worldName = path.basename(config.worldPath);
    await fs.ensureDir(TEMP_DIR);
    zipPath = path.join(TEMP_DIR, `${worldName}-${Date.now()}.zip`);

    await compressFolder(config.worldPath, zipPath);
    const doc = await uploadBackup(worldName, zipPath);

    res.json({
      success: true,
      worldName,
      uploadedAt: doc.uploadedAt,
      sizeBytes: doc.fileSize,
      storage: doc.storageType
    });
  } catch (err) {
    res.status(500).json({ error: 'Upload failed', message: err.message });
  } finally {
    if (zipPath) {
      await fs.remove(zipPath).catch(() => {});
    }
  }
}

async function downloadWorld(req, res) {
  let zipPath;
  try {
    const config = await readConfig();
    if (!config.worldPath) {
      return res.status(400).json({ error: 'No world folder selected yet' });
    }

    if (!getConnectionStatus()) {
      return res.status(503).json({ error: 'Database is not connected' });
    }

    const worldName = path.basename(config.worldPath);
    const latest = await getLatestBackup(worldName);
    if (!latest) {
      return res.status(404).json({ error: `No backup found for "${worldName}"` });
    }

    await fs.ensureDir(TEMP_DIR);
    zipPath = path.join(TEMP_DIR, `${worldName}-restore-${Date.now()}.zip`);
    await downloadBackupToFile(latest, zipPath);

    const restoredPath = await extractZip(zipPath, config.worldPath, worldName);

    res.json({
      success: true,
      worldName,
      restoredPath,
      uploadedAt: latest.uploadedAt
    });
  } catch (err) {
    res.status(500).json({ error: 'Download/restore failed', message: err.message });
  } finally {
    if (zipPath) {
      await fs.remove(zipPath).catch(() => {});
    }
  }
}

module.exports = { getStatus, selectFolder, uploadWorld, downloadWorld };
