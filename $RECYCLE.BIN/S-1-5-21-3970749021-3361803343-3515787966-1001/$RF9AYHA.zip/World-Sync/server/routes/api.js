const express = require('express');
const router = express.Router();
const controller = require('../controllers/worldController');

router.get('/status', controller.getStatus);
router.post('/select-folder', controller.selectFolder);
router.post('/upload', controller.uploadWorld);
router.post('/download', controller.downloadWorld);

module.exports = router;
