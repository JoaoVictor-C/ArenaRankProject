const mongoose = require('mongoose');

let isConnected = false;

async function connectDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error('MONGODB_URI is not set in .env');
  }

  mongoose.connection.on('connected', () => {
    isConnected = true;
  });
  mongoose.connection.on('disconnected', () => {
    isConnected = false;
  });

  await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 8000
  });

  return mongoose.connection;
}

function getConnectionStatus() {
  return isConnected;
}

module.exports = { connectDB, getConnectionStatus };
