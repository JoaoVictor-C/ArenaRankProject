const fs = require('fs-extra');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', '..', 'config.json');
const DEFAULT_CONFIG = { worldPath: '' };

function getEnvWorldPath() {
  return process.env.WORLD_PATH || '';
}

async function readConfig() {
  const envWorldPath = getEnvWorldPath();
  try {
    const exists = await fs.pathExists(CONFIG_PATH);
    if (!exists) {
      const initialConfig = { worldPath: envWorldPath };
      await fs.writeJson(CONFIG_PATH, initialConfig, { spaces: 2 });
      return initialConfig;
    }
    const data = await fs.readJson(CONFIG_PATH);
    return { worldPath: data.worldPath || envWorldPath || '' };
  } catch (err) {
    console.error('Failed to read config.json, using defaults:', err.message);
    return { worldPath: envWorldPath || '' };
  }
}

async function writeConfig(update) {
  const current = await readConfig();
  const next = { ...current, ...update };
  await fs.writeJson(CONFIG_PATH, next, { spaces: 2 });
  return next;
}

module.exports = { readConfig, writeConfig, CONFIG_PATH };
