# file-sync-cli

A lightweight, personal file-sync CLI. Sync **one folder at a time** between
computers using MongoDB Atlas as the backend — no server of your own to run,
just a CLI that talks to Atlas directly via the MongoDB driver.

Think of it as a manual, single-folder Google Drive: you run `sync upload` on
one machine and `sync download` on another, and only the files that actually
changed are transferred (compared by SHA-256 hash).

## How it works

- **Metadata + small file contents** live in a single `files` collection.
- **Large file contents** (≥ 15 MB, based on original file size) live in
  GridFS (`fs.files` / `fs.chunks`), which MongoDB uses internally to split
  big blobs into 255 KB chunks.
- Files are **gzip-compressed before storage** where it's likely to help, to
  get more mileage out of the 512 MB free tier.
- Everything lives in one Atlas cluster, inspectable from the Atlas web UI's
  "Browse Collections" view.

### Why the 16 MB split?

MongoDB documents are capped at 16 MB (BSON limit). Most personal files
(photos, docs, code) are well under that, so storing them as a `Binary` field
directly on the metadata document keeps things simple — one document, one
read, no separate collection to manage. Anything close to or over the limit
has to go through GridFS instead, which chunks the file across many small
documents in `fs.chunks` and stores just a pointer (`gridfs_id`) on the
`files` document.

The CLI draws the line at **15 MB** (not 16) to leave headroom in the BSON
document for the other metadata fields (path, hash, timestamps, etc.). The
threshold is checked against the file's *original* size, before compression
— so the inline/GridFS decision stays simple and doesn't require buffering a
huge file in memory just to see how well it compresses.

### Compression

Every file is gzipped with Node's built-in `zlib` before being written to
Mongo, with two exceptions:

- **Known-incompressible formats** (jpg, png, mp4, mp3, zip, pdf, docx, and
  similar — see `src/compress.js`) skip compression entirely by extension,
  since gzipping them wastes CPU and can even make them slightly larger.
- **Inline (small) files** are compressed and compared: since the whole file
  is already read into memory for the inline path, we gzip it, check whether
  the result is actually smaller, and fall back to the original bytes if not
  (protects against gzip's per-file overhead on already-small files).
- **GridFS (large) files** are streamed, so there's no cheap way to compress
  and compare — compression is applied whenever the extension isn't on the
  skip list, without a second pass. In the rare case that's wrong for a
  particular file, the worst case is a few bytes of gzip overhead.

Each document's `compressed` flag records what happened, and `stored_bytes`
records the actual bytes written (compressed or not) — that's what `sync
list` and the free-space calculation use, since it reflects real Atlas
usage. **`sha256` is always computed from the original, uncompressed file**,
so change detection (`sync status`, and the skip logic in `upload`/
`download`) is unaffected by compression either way.

## Data model

Single collection: **`files`**

| Field           | Type                  | Notes                                             |
|-----------------|-----------------------|----------------------------------------------------|
| `folder_name`   | string                | Logical folder name (defaults to the local folder's basename) |
| `relative_path` | string                | POSIX-style path relative to the folder root       |
| `sha256`        | string                | Hex SHA-256 of the **original, uncompressed** file contents |
| `size_bytes`    | number                | Original file size in bytes                        |
| `stored_bytes`  | number                | Actual bytes written to Mongo (post-compression); what `sync list` totals |
| `compressed`    | boolean               | Whether `content`/the GridFS blob is gzipped        |
| `updated_at`    | date                  | Last upload time                                   |
| `storage`       | `"inline"` \| `"gridfs"` | Which storage strategy was used for this file   |
| `content`       | Binary (optional)     | Present only when `storage === "inline"`; gzipped iff `compressed` |
| `gridfs_id`     | ObjectId (optional)   | Present only when `storage === "gridfs"`; points into `fs.files` |

Unique index: `{ folder_name: 1, relative_path: 1 }` — one document per file
per folder, so re-uploading a changed file is an upsert, not a duplicate.

Plus GridFS's own collections (`fs.files`, `fs.chunks`), managed entirely by
the MongoDB driver's `GridFSBucket` — you never touch these directly, but you
can see them in the Atlas UI.

**To manually check your usage / clean up:** open Atlas → Browse Collections
→ your database. The `files` collection shows every synced file's metadata
(and, for small files, the raw bytes). `fs.files` shows GridFS entries for
big files; `fs.chunks` shows the actual chunked data. Deleting a folder with
`sync delete <folder>` removes all of these for that folder in one go, so you
shouldn't normally need to touch `fs.chunks` by hand — but it's there to
inspect if something looks off.

## Setup

### 1. Create a free Atlas cluster

1. Go to [mongodb.com/cloud/atlas](https://mongodb.com/cloud/atlas) and
   create a free account (or sign in).
2. Create a new **Project**, then **Build a Database** → choose the **M0
   (Free)** tier → pick any region close to you → create the cluster.
3. Under **Security → Database Access**, create a database user with a
   username/password (or use the one Atlas prompts you to create during
   setup).
4. Under **Security → Network Access**, add your current IP address (or
   `0.0.0.0/0` for "allow from anywhere" if you sync from multiple machines
   with changing IPs — less strict, but fine for a personal project).

### 2. Get your connection string

1. On the cluster page, click **Connect** → **Drivers** → select Node.js.
2. Copy the connection string, which looks like:
   ```
   mongodb+srv://<username>:<password>@<cluster-host>/?retryWrites=true&w=majority
   ```
3. Replace `<username>` and `<password>` with your database user's
   credentials (URL-encode any special characters in the password).

### 3. Configure the CLI

The CLI reads its connection string from, in order of precedence:

1. The `SYNC_MONGO_URI` environment variable, or
2. A `mongoUri` field in `~/.sync-cli/config.json`

Easiest path — set the environment variable in your shell profile:

```bash
export SYNC_MONGO_URI="mongodb+srv://myuser:mypassword@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority"
```

Or copy `.env.example` to `.env`, fill it in, and load it into your shell
however you prefer (this project does not auto-load `.env` files — that's a
deliberate choice to avoid an extra dependency, since a personal CLI you run
a few times a day doesn't need it).

Optionally set `SYNC_DB_NAME` to use a database name other than the default
`filesync`.

**Never commit real credentials.** `.env` is git-ignored; `~/.sync-cli/config.json`
lives outside the repo entirely.

### 4. Install

```bash
npm install
npm link   # makes the `sync` command available globally
```

(Or run without linking: `node bin/sync.js <command>`.)

## Commands

```bash
# Point the CLI at a local folder — this becomes the "active" folder
sync use ~/Documents/my-notes

# Upload the active folder (only changed/new files are sent)
sync upload

# ...or upload a specific folder without changing the active one
sync upload ~/Documents/other-folder

# Download the active folder's files into its original local path
sync download

# ...or download into a different destination
sync download ~/Documents/my-notes-restored

# List every synced folder with file counts, sizes, and total Atlas usage
sync list

# See what's changed locally vs. what's stored, without uploading
sync status

# Permanently delete a folder's files + metadata (including GridFS chunks)
sync delete my-notes
```

### Example session

```
$ sync use ~/Documents/my-notes
✔ Active folder set to "my-notes" (/Users/joao/Documents/my-notes)

$ sync upload
  upload   notes/2026.md (12.4 KB -> 3.8 KB gzip)
  upload   photos/trip.jpg (3.21 MB)
  skip     notes/todo.md

Summary
  Uploaded: 2  Skipped: 1  Failed: 0
  Uploaded bytes: 3.20 MB stored (3.22 MB original)
  Compression saved: 8.6 KB (0.3%)
  Atlas usage: 3.20 MB / 512.00 MB (0.6%)

$ sync list
Synced folders:
  my-notes (active)  -  3 files, 3.20 MB

Total Atlas usage: 3.20 MB / 512.00 MB (0.6%)
```

(`photos/trip.jpg` isn't compressed — `.jpg` is on the incompressible-format
skip list — while the Markdown note shrinks noticeably.)

On a second machine:

```
$ sync use ~/Documents/my-notes    # same folder name
$ sync download
  download notes/2026.md (12.4 KB)
  download photos/trip.jpg (3.21 MB)
  download notes/todo.md (890 B)

Summary
  Downloaded: 3  Skipped: 0  Failed: 0
  ...
```

## Web UI

Prefer clicking over typing commands? `sync ui` starts a small local web
server and opens it in your browser:

```bash
sync ui                  # opens http://127.0.0.1:4478 automatically
sync ui --port 5000      # use a different port
sync ui --no-open        # print the URL instead of auto-opening a tab
```

It's **not a hosted server** — it binds only to `127.0.0.1` (unreachable from
any other device), runs only while the command is active, and stops the
moment you hit `Ctrl+C`. It talks to Atlas exactly the same way the CLI
does, using the same `SYNC_MONGO_URI`/config. Nothing about your setup or
constraints changes — this is just a GUI on top of the same commands.

From the page you can:

- See the active folder and switch to a different one with a built-in
  directory browser (no need to type paths by hand)
- Upload / download the active folder, with a live per-file log streamed in
  as it happens (via Server-Sent Events)
- Run `status` to preview changes before uploading
- See every synced folder with file counts, sizes, and the Atlas usage bar
- Delete a folder's data (with a confirmation prompt) directly from the list

The UI is a static `index.html`/`app.js`/`styles.css` (no build step, no
framework) served by an Express app in `src/server/index.js`, calling the
exact same `src/commands/*.js` functions the CLI uses — so behavior (hash
comparisons, compression, GridFS cleanup, etc.) is identical between the two
interfaces by construction, not by keeping two implementations in sync by
hand.

## Sync behavior & limitations

- **Change detection** is hash-based: every file is SHA-256'd and compared
  against the stored hash before transferring, so unchanged files are
  skipped on both upload and download.
- **Structure is preserved**: relative paths (POSIX-style internally) are
  recreated under the destination folder on download.
- **Adds and modifies are handled**; **deletion-sync is not** — if you delete
  a local file, `sync upload` won't remove it remotely, and `sync status`
  will just flag it as "missing locally, still in DB". To fully remove a
  folder's data (e.g. to free up space), use `sync delete <folder>`. The
  places where deletion-sync would plug in are marked with comments in
  `src/commands/upload.js`, `src/commands/download.js`, and
  `src/commands/status.js`.
- **One folder identity per basename**: the "folder name" used as the
  grouping key in MongoDB is the local folder's basename (e.g.
  `~/Documents/my-notes` → `my-notes`). Syncing two different local folders
  that happen to share a basename will merge them in the DB — keep folder
  names distinct if that matters to you.

## Error handling

The CLI gives targeted messages for the common failure modes:

- **Auth failures** (bad username/password in the connection string)
- **Network failures** (unreachable cluster, DNS issues, IP not allowlisted
  in Atlas Network Access)
- **Storage-limit errors** (approaching/exceeding the M0 512 MB cap)
- **Missing/invalid local folders**

Every command exits non-zero on failure so it's safe to use in scripts.
