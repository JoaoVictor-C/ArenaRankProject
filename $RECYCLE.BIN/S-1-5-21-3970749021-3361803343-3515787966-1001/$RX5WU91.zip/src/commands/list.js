import chalk from 'chalk';
import { formatBytes } from '../format.js';
import { ATLAS_FREE_TIER_BYTES } from '../constants.js';

export async function listCommand({ config, db, files }) {
  const agg = await files
    .aggregate([
      { $group: { _id: '$folder_name', count: { $sum: 1 }, totalBytes: { $sum: '$stored_bytes' } } },
      { $sort: { _id: 1 } },
    ])
    .toArray();

  if (agg.length === 0) {
    console.log('No synced folders found.');
  } else {
    console.log(chalk.bold('Synced folders:'));
    for (const f of agg) {
      const marker = config.activeFolder?.name === f._id ? chalk.green(' (active)') : '';
      console.log(`  ${f._id}${marker}  -  ${f.count} files, ${formatBytes(f.totalBytes)}`);
    }
  }

  const stats = await db.command({ dbStats: 1 });
  const usedBytes = stats.dataSize + stats.indexSize;

  console.log('');
  console.log(
    `Total Atlas usage: ${formatBytes(usedBytes)} / ${formatBytes(ATLAS_FREE_TIER_BYTES)} ` +
      `(${((usedBytes / ATLAS_FREE_TIER_BYTES) * 100).toFixed(1)}%)`
  );

  return {
    folders: agg.map((f) => ({ name: f._id, count: f.count, totalBytes: f.totalBytes })),
    activeFolderName: config.activeFolder?.name ?? null,
    usedBytes,
    limitBytes: ATLAS_FREE_TIER_BYTES,
  };
}
