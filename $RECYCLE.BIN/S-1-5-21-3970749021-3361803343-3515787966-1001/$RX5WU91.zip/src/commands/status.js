import fs from 'node:fs';
import chalk from 'chalk';
import { walkFiles } from '../fsWalk.js';
import { hashFile } from '../hash.js';

export async function statusCommand({ config, files }) {
  if (!config.activeFolder) {
    throw new Error('No active folder set. Run "sync use <folder>" first.');
  }

  const { name: folderName, path: folderPath } = config.activeFolder;
  if (!fs.existsSync(folderPath)) {
    throw new Error(`Active folder no longer exists on disk: ${folderPath}`);
  }

  const localFiles = walkFiles(folderPath);
  const remoteDocs = await files
    .find({ folder_name: folderName }, { projection: { relative_path: 1, sha256: 1 } })
    .toArray();
  const remoteMap = new Map(remoteDocs.map((d) => [d.relative_path, d.sha256]));

  const localRelPaths = new Set();
  let added = 0;
  let modified = 0;
  let unchanged = 0;
  const changes = [];

  for (const { absolutePath, relativePath } of localFiles) {
    localRelPaths.add(relativePath);
    const sha256 = await hashFile(absolutePath);
    const remoteHash = remoteMap.get(relativePath);

    if (remoteHash === undefined) {
      added++;
      changes.push({ kind: 'new', path: relativePath });
    } else if (remoteHash !== sha256) {
      modified++;
      changes.push({ kind: 'modified', path: relativePath });
    } else {
      unchanged++;
    }
  }

  const missingLocally = remoteDocs.map((d) => d.relative_path).filter((rel) => !localRelPaths.has(rel));

  console.log(chalk.bold(`Status for "${folderName}" (${folderPath})`));
  for (const change of changes) {
    if (change.kind === 'new') {
      console.log(chalk.green('  new     '), change.path);
    } else {
      console.log(chalk.yellow('  modified'), change.path);
    }
  }
  for (const rel of missingLocally) {
    console.log(chalk.red('  missing '), rel, chalk.dim('(in DB, not on disk)'));
  }

  console.log('');
  console.log(
    `  New: ${added}  Modified: ${modified}  Unchanged: ${unchanged}  Missing locally: ${missingLocally.length}`
  );
  if (added || modified) {
    console.log(chalk.dim('  Run "sync upload" to push changes.'));
  }
  if (missingLocally.length) {
    // Deletion-sync would go here: currently these files just stay in
    // the DB forever unless removed explicitly with "sync delete".
    console.log(chalk.dim('  Deletion-sync is not implemented yet; missing files remain in the DB.'));
  }

  return {
    folderName,
    folderPath,
    changes,
    missingLocally,
    counts: { added, modified, unchanged, missingLocally: missingLocally.length },
  };
}
