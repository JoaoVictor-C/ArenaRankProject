import chalk from 'chalk';

export async function deleteCommand({ files, bucket }, folderName) {
  const docs = await files.find({ folder_name: folderName }).toArray();
  if (docs.length === 0) {
    console.log(chalk.yellow(`No data found for folder "${folderName}".`));
    return { folderName, deletedCount: 0, gridfsDeleted: 0 };
  }

  let gridfsDeleted = 0;
  for (const doc of docs) {
    if (doc.storage === 'gridfs' && doc.gridfs_id) {
      try {
        // bucket.delete() removes both the fs.files entry and all of its
        // fs.chunks, so nothing is left orphaned.
        await bucket.delete(doc.gridfs_id);
        gridfsDeleted++;
      } catch (err) {
        console.log(chalk.red('  error'), `deleting GridFS blob for ${doc.relative_path}:`, err.message);
      }
    }
  }

  const result = await files.deleteMany({ folder_name: folderName });

  console.log(
    chalk.green('✔'),
    `Deleted ${result.deletedCount} file record(s) and ${gridfsDeleted} GridFS blob(s) for "${folderName}".`
  );

  return { folderName, deletedCount: result.deletedCount, gridfsDeleted };
}
