import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import chalk from 'chalk';
import { walkFiles } from '../fsWalk.js';
import { hashFile } from '../hash.js';
import { formatBytes } from '../format.js';
import { resolveFolderPath } from '../folder.js';
import { shouldAttemptCompression, compressBuffer } from '../compress.js';
import { INLINE_THRESHOLD_BYTES, ATLAS_FREE_TIER_BYTES } from '../constants.js';

// GridFS-bound files are streamed rather than buffered, so we can't do a
// compress-then-compare like the inline path does — we commit to
// compressing (or not) up front, based on file extension alone.
function uploadToGridFS(bucket, absolutePath, relativePath, compress) {
  return new Promise((resolve, reject) => {
    const uploadStream = bucket.openUploadStream(relativePath);
    const source = fs.createReadStream(absolutePath);
    source.on('error', reject);

    const pipeline = compress ? source.pipe(zlib.createGzip()) : source;
    pipeline
      .pipe(uploadStream)
      .on('error', reject)
      .on('finish', () => resolve({ id: uploadStream.id, storedBytes: uploadStream.length }));
  });
}

// onEvent, if given, is called with a structured event for every file
// processed and once more with the final summary — used by the web UI to
// stream live progress. It's unused by the CLI, which relies on the
// console output below instead.
export async function uploadCommand({ config, db, files, bucket }, folderArg, onEvent) {
  const folderPath = resolveFolderPath(config, folderArg);
  const folderName = path.basename(folderPath);

  const localFiles = walkFiles(folderPath);
  if (localFiles.length === 0) {
    console.log(chalk.yellow('No files found in folder.'));
    const empty = { folderName, uploaded: 0, skipped: 0, failed: 0, uploadedOriginalBytes: 0, uploadedStoredBytes: 0 };
    onEvent?.({ kind: 'summary', summary: empty });
    return empty;
  }

  let uploaded = 0;
  let skipped = 0;
  let failed = 0;
  let uploadedOriginalBytes = 0;
  let uploadedStoredBytes = 0;
  const localRelPaths = new Set();

  for (const { absolutePath, relativePath } of localFiles) {
    localRelPaths.add(relativePath);
    try {
      const stat = fs.statSync(absolutePath);
      const sha256 = await hashFile(absolutePath);

      const existing = await files.findOne(
        { folder_name: folderName, relative_path: relativePath },
        { projection: { sha256: 1, storage: 1, gridfs_id: 1 } }
      );

      if (existing && existing.sha256 === sha256) {
        console.log(chalk.gray('  skip    '), relativePath);
        onEvent?.({ kind: 'file', action: 'skip', path: relativePath });
        skipped++;
        continue;
      }

      // If we're replacing a file that used to live in GridFS, drop the
      // old blob first so we don't leak orphaned chunks.
      if (existing && existing.storage === 'gridfs' && existing.gridfs_id) {
        await bucket.delete(existing.gridfs_id);
      }

      let storage;
      let storedBytes;
      let compressed;
      let gridfsId;
      let content;

      if (stat.size < INLINE_THRESHOLD_BYTES) {
        const original = fs.readFileSync(absolutePath);
        ({ content, compressed } = shouldAttemptCompression(absolutePath)
          ? compressBuffer(original)
          : { content: original, compressed: false });
        storage = 'inline';
        storedBytes = content.length;
      } else {
        compressed = shouldAttemptCompression(absolutePath);
        ({ id: gridfsId, storedBytes } = await uploadToGridFS(bucket, absolutePath, relativePath, compressed));
        storage = 'gridfs';
      }

      const update = {
        $set: {
          folder_name: folderName,
          relative_path: relativePath,
          sha256,
          size_bytes: stat.size,
          stored_bytes: storedBytes,
          compressed,
          updated_at: new Date(),
          storage,
        },
      };
      if (storage === 'inline') {
        update.$set.content = content;
        update.$unset = { gridfs_id: '' };
      } else {
        update.$set.gridfs_id = gridfsId;
        update.$unset = { content: '' };
      }

      await files.updateOne({ folder_name: folderName, relative_path: relativePath }, update, { upsert: true });

      const sizeLabel = compressed
        ? `${formatBytes(stat.size)} -> ${formatBytes(storedBytes)} gzip`
        : formatBytes(stat.size);
      console.log(chalk.green('  upload  '), relativePath, chalk.dim(`(${sizeLabel})`));
      onEvent?.({
        kind: 'file',
        action: 'upload',
        path: relativePath,
        originalBytes: stat.size,
        storedBytes,
        compressed,
      });
      uploaded++;
      uploadedOriginalBytes += stat.size;
      uploadedStoredBytes += storedBytes;
    } catch (err) {
      failed++;
      console.log(chalk.red('  error   '), relativePath, '-', err.message);
      onEvent?.({ kind: 'file', action: 'error', path: relativePath, message: err.message });
    }
  }

  // Deletion-sync would go here: fetch remote docs for folderName, diff
  // their relative_path values against localRelPaths, and remove (or
  // tombstone) any remote doc whose path is no longer present locally.
  // Left out intentionally per spec (add/modify only, for now).

  const stats = await db.command({ dbStats: 1 });
  const usedBytes = stats.dataSize + stats.indexSize;

  console.log('');
  console.log(chalk.bold('Summary'));
  console.log(`  Uploaded: ${uploaded}  Skipped: ${skipped}  Failed: ${failed}`);
  console.log(`  Uploaded bytes: ${formatBytes(uploadedStoredBytes)} stored (${formatBytes(uploadedOriginalBytes)} original)`);
  if (uploadedStoredBytes < uploadedOriginalBytes) {
    const saved = uploadedOriginalBytes - uploadedStoredBytes;
    console.log(`  Compression saved: ${formatBytes(saved)} (${((saved / uploadedOriginalBytes) * 100).toFixed(1)}%)`);
  }
  console.log(
    `  Atlas usage: ${formatBytes(usedBytes)} / ${formatBytes(ATLAS_FREE_TIER_BYTES)} ` +
      `(${((usedBytes / ATLAS_FREE_TIER_BYTES) * 100).toFixed(1)}%)`
  );

  const summary = {
    folderName,
    uploaded,
    skipped,
    failed,
    uploadedOriginalBytes,
    uploadedStoredBytes,
    usedBytes,
    limitBytes: ATLAS_FREE_TIER_BYTES,
  };
  onEvent?.({ kind: 'summary', summary });
  return summary;
}
