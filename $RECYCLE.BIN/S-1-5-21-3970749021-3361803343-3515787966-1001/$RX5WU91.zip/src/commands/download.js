import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import chalk from 'chalk';
import { hashFile } from '../hash.js';
import { formatBytes } from '../format.js';
import { decompressBuffer } from '../compress.js';
import { ATLAS_FREE_TIER_BYTES } from '../constants.js';

function downloadFromGridFS(bucket, gridfsId, destPath, compressed) {
  return new Promise((resolve, reject) => {
    const downloadStream = bucket.openDownloadStream(gridfsId);
    const writeStream = fs.createWriteStream(destPath);
    downloadStream.on('error', reject);
    writeStream.on('error', reject);
    writeStream.on('finish', resolve);

    const pipeline = compressed ? downloadStream.pipe(zlib.createGunzip()) : downloadStream;
    pipeline.on('error', reject);
    pipeline.pipe(writeStream);
  });
}

// onEvent, if given, is called with a structured event for every file
// processed and once more with the final summary — used by the web UI to
// stream live progress. It's unused by the CLI, which relies on the
// console output below instead.
export async function downloadCommand({ config, db, files, bucket }, destArg, onEvent) {
  if (!config.activeFolder) {
    throw new Error('No active folder set. Run "sync use <folder>" first.');
  }

  const folderName = config.activeFolder.name;
  const dest = destArg ? path.resolve(destArg) : config.activeFolder.path;
  fs.mkdirSync(dest, { recursive: true });

  const remoteFiles = await files.find({ folder_name: folderName }).toArray();
  if (remoteFiles.length === 0) {
    console.log(chalk.yellow(`No files found for folder "${folderName}" in the database.`));
    const empty = { folderName, downloaded: 0, skipped: 0, failed: 0, downloadedBytes: 0 };
    onEvent?.({ kind: 'summary', summary: empty });
    return empty;
  }

  let downloaded = 0;
  let skipped = 0;
  let failed = 0;
  let downloadedBytes = 0;

  for (const doc of remoteFiles) {
    const localPath = path.join(dest, ...doc.relative_path.split('/'));
    try {
      if (fs.existsSync(localPath)) {
        const localHash = await hashFile(localPath);
        if (localHash === doc.sha256) {
          console.log(chalk.gray('  skip    '), doc.relative_path);
          onEvent?.({ kind: 'file', action: 'skip', path: doc.relative_path });
          skipped++;
          continue;
        }
      }

      fs.mkdirSync(path.dirname(localPath), { recursive: true });

      if (doc.storage === 'inline') {
        const raw = doc.content.buffer;
        fs.writeFileSync(localPath, doc.compressed ? decompressBuffer(raw) : raw);
      } else {
        await downloadFromGridFS(bucket, doc.gridfs_id, localPath, doc.compressed);
      }

      console.log(chalk.cyan('  download'), doc.relative_path, chalk.dim(`(${formatBytes(doc.size_bytes)})`));
      onEvent?.({ kind: 'file', action: 'download', path: doc.relative_path, originalBytes: doc.size_bytes });
      downloaded++;
      downloadedBytes += doc.size_bytes;
    } catch (err) {
      failed++;
      console.log(chalk.red('  error   '), doc.relative_path, '-', err.message);
      onEvent?.({ kind: 'file', action: 'error', path: doc.relative_path, message: err.message });
    }
  }

  // Deletion-sync would go here: files removed from the remote folder but
  // still present locally would need a tombstone flag on the doc (or a
  // full diff pass) before we could safely remove them from disk.

  const stats = await db.command({ dbStats: 1 });
  const usedBytes = stats.dataSize + stats.indexSize;

  console.log('');
  console.log(chalk.bold('Summary'));
  console.log(`  Downloaded: ${downloaded}  Skipped: ${skipped}  Failed: ${failed}`);
  console.log(`  Downloaded bytes: ${formatBytes(downloadedBytes)}`);
  console.log(
    `  Atlas usage: ${formatBytes(usedBytes)} / ${formatBytes(ATLAS_FREE_TIER_BYTES)} ` +
      `(${((usedBytes / ATLAS_FREE_TIER_BYTES) * 100).toFixed(1)}%)`
  );

  const summary = { folderName, downloaded, skipped, failed, downloadedBytes, usedBytes, limitBytes: ATLAS_FREE_TIER_BYTES };
  onEvent?.({ kind: 'summary', summary });
  return summary;
}
