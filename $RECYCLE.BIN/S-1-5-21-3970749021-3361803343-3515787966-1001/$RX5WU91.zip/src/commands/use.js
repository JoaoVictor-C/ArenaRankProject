import fs from 'node:fs';
import path from 'node:path';
import chalk from 'chalk';
import { loadConfig, saveConfig } from '../config.js';

export async function useCommand(folderPath) {
  const absolute = path.resolve(folderPath);

  if (!fs.existsSync(absolute) || !fs.statSync(absolute).isDirectory()) {
    throw new Error(`Folder not found: ${absolute}`);
  }

  const name = path.basename(absolute);
  const config = loadConfig();
  config.activeFolder = { name, path: absolute };
  saveConfig(config);

  console.log(chalk.green('✔'), `Active folder set to "${name}" (${absolute})`);

  return { name, path: absolute };
}
