import fs from 'node:fs';
import path from 'node:path';

// Resolves the local folder path to operate on: an explicit argument wins,
// otherwise falls back to the active folder stored in config.
export function resolveFolderPath(config, folderArg) {
  if (folderArg) {
    const abs = path.resolve(folderArg);
    if (!fs.existsSync(abs) || !fs.statSync(abs).isDirectory()) {
      throw new Error(`Folder not found: ${abs}`);
    }
    return abs;
  }

  if (config.activeFolder?.path) {
    if (!fs.existsSync(config.activeFolder.path)) {
      throw new Error(
        `Active folder no longer exists on disk: ${config.activeFolder.path}. Run "sync use <folder>" again.`
      );
    }
    return config.activeFolder.path;
  }

  throw new Error('No active folder set. Run "sync use <folder>" first, or pass a folder path.');
}
