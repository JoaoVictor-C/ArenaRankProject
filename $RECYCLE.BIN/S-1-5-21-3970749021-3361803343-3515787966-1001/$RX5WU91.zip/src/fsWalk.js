import fs from 'node:fs';
import path from 'node:path';

// Recursively lists files under rootDir, returning POSIX-style relative
// paths so they are portable between Windows/macOS/Linux.
export function walkFiles(rootDir) {
  const results = [];

  function walk(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile()) {
        const relativePath = path.relative(rootDir, full).split(path.sep).join('/');
        results.push({ absolutePath: full, relativePath });
      }
    }
  }

  walk(rootDir);
  return results;
}
