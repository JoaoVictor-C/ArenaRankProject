import { Command } from 'commander';
import chalk from 'chalk';
import { loadConfig } from './config.js';
import { connect, disconnect } from './db.js';
import { useCommand } from './commands/use.js';
import { uploadCommand } from './commands/upload.js';
import { downloadCommand } from './commands/download.js';
import { listCommand } from './commands/list.js';
import { deleteCommand } from './commands/delete.js';
import { statusCommand } from './commands/status.js';
import { startServer } from './server/index.js';

function handleError(err) {
  const message = err?.message || String(err);

  if (err?.name === 'MongoServerError' && (err.codeName === 'AuthenticationFailed' || err.code === 18)) {
    console.error(chalk.red('✖ Authentication failed.'), 'Check the username/password in your SYNC_MONGO_URI.');
  } else if (
    err?.name === 'MongoServerSelectionError' ||
    /ENOTFOUND|ECONNREFUSED|ETIMEDOUT/.test(message)
  ) {
    console.error(
      chalk.red('✖ Could not reach MongoDB Atlas.'),
      'Check your network connection, the connection string, and that your current IP is allowlisted under Atlas → Network Access.'
    );
  } else if (err?.code === 8000 || /quota|over your space|disk quota|no space/i.test(message)) {
    console.error(
      chalk.red('✖ Storage limit reached.'),
      'You may be at/near the 512 MB Atlas free-tier limit. Run "sync list" and "sync delete <folder>" to free up space.'
    );
  } else {
    console.error(chalk.red('✖'), message);
  }
}

// Wraps a command action with standard error handling, without touching
// the database — used for commands that only touch local config/disk.
function wrap(fn) {
  return async (...args) => {
    try {
      await fn(...args);
    } catch (err) {
      handleError(err);
      process.exitCode = 1;
    }
  };
}

// Wraps a command action that needs a Mongo connection: connects once for
// this invocation, passes { config, db, files, bucket } as the first
// argument to fn, and always disconnects afterwards.
function withDb(fn) {
  return async (...args) => {
    try {
      const config = loadConfig();
      const { db, files, bucket } = await connect(config);
      try {
        await fn({ config, db, files, bucket }, ...args);
      } finally {
        await disconnect();
      }
    } catch (err) {
      handleError(err);
      process.exitCode = 1;
    }
  };
}

const program = new Command();

program
  .name('sync')
  .description('Lightweight personal file-sync CLI backed by MongoDB Atlas (no server required)')
  .version('1.0.0');

program
  .command('use')
  .argument('<folder>', 'local folder to set as active')
  .description('Set the active folder for future upload/download/status commands')
  .action(wrap(useCommand));

program
  .command('upload')
  .argument('[folder]', 'folder to upload (defaults to the active folder)')
  .description('Upload changed files from the active (or given) folder')
  .action(withDb((ctx, folder) => uploadCommand(ctx, folder)));

program
  .command('download')
  .argument('[dest]', 'destination directory (defaults to the active folder\'s local path)')
  .description('Download the active folder\'s files')
  .action(withDb((ctx, dest) => downloadCommand(ctx, dest)));

program
  .command('list')
  .description('List synced folders with file counts, sizes, and total Atlas usage')
  .action(withDb((ctx) => listCommand(ctx)));

program
  .command('delete')
  .argument('<folder>', 'folder name as shown by "sync list"')
  .description('Delete a folder\'s files and metadata, including any GridFS chunks')
  .action(withDb((ctx, folder) => deleteCommand(ctx, folder)));

program
  .command('status')
  .description('Show which local files in the active folder differ from what is stored remotely')
  .action(withDb((ctx) => statusCommand(ctx)));

program
  .command('ui')
  .option('-p, --port <port>', 'port to listen on', '4478')
  .option('--no-open', 'do not automatically open a browser tab')
  .description('Start a local-only web UI (binds to 127.0.0.1) for browsing and syncing folders')
  .action(async (opts) => {
    try {
      await startServer({ port: Number(opts.port), open: opts.open });
    } catch (err) {
      handleError(err);
      process.exitCode = 1;
    }
  });

program.parseAsync(process.argv);
