import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const CONFIG_DIR = path.join(os.homedir(), '.sync-cli');
const CONFIG_PATH = path.join(CONFIG_DIR, 'config.json');

export function loadConfig() {
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    if (err.code === 'ENOENT') return {};
    throw new Error(`Failed to read config at ${CONFIG_PATH}: ${err.message}`);
  }
}

export function saveConfig(config) {
  fs.mkdirSync(CONFIG_DIR, { recursive: true });
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
}

export function getMongoUri(config) {
  const uri = process.env.SYNC_MONGO_URI || "mongodb+srv://joao:b34R2GWm4jPUtDWF@world-sync.tbaokxs.mongodb.net/?appName=world-sync";
  if (!uri) {
    throw new Error(
      `No MongoDB connection string found. Set the SYNC_MONGO_URI environment variable, ` +
        `or add a "mongoUri" field to ${CONFIG_PATH}.`
    );
  }
  return uri;
}

export function getDbName(config) {
  return process.env.SYNC_DB_NAME || config.dbName || 'filesync';
}

export { CONFIG_PATH };
