import { MongoClient, GridFSBucket } from 'mongodb';
import { getMongoUri, getDbName } from './config.js';

let client;

export async function connect(config) {
  const uri = getMongoUri(config);
  client = new MongoClient(uri, { serverSelectionTimeoutMS: 8000 });

  try {
    await client.connect();
  } catch (err) {
    throw new Error(`Could not connect to MongoDB: ${err.message}`);
  }

  const db = client.db(getDbName(config));
  const files = db.collection('files');
  const bucket = new GridFSBucket(db, { bucketName: 'fs' });

  await files.createIndex({ folder_name: 1, relative_path: 1 }, { unique: true });

  return { client, db, files, bucket };
}

export async function disconnect() {
  if (client) {
    await client.close();
    client = undefined;
  }
}
