// Files smaller than this are stored inline as a Binary field on the
// `files` document. BSON documents cap out at 16 MB, so we stop short of
// that to leave headroom for the other fields (path, hashes, etc).
export const INLINE_THRESHOLD_BYTES = 15 * 1024 * 1024;

// MongoDB Atlas M0 (free) tier storage limit.
export const ATLAS_FREE_TIER_BYTES = 512 * 1024 * 1024;
