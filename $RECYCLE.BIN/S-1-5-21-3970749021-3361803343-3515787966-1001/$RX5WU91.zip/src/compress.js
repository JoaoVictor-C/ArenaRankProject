import path from 'node:path';
import zlib from 'node:zlib';

// Formats that are already compressed (media, archives, office docs, PDFs).
// Gzipping these wastes CPU and can even grow the file slightly, so we skip
// compression entirely for them.
const INCOMPRESSIBLE_EXTENSIONS = new Set([
  '.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.heic', '.avif',
  '.mp4', '.mov', '.mkv', '.avi', '.webm',
  '.mp3', '.m4a', '.flac', '.ogg', '.wav',
  '.zip', '.gz', '.bz2', '.xz', '.7z', '.rar', '.tar',
  '.pdf',
  '.docx', '.xlsx', '.pptx', '.odt',
  '.woff', '.woff2',
]);

export function shouldAttemptCompression(filePath) {
  return !INCOMPRESSIBLE_EXTENSIONS.has(path.extname(filePath).toLowerCase());
}

// Only keeps the gzipped version if it's actually smaller — tiny files can
// come out larger than the original once gzip's header/footer overhead is
// added.
export function compressBuffer(buffer) {
  const gzipped = zlib.gzipSync(buffer);
  return gzipped.length < buffer.length
    ? { content: gzipped, compressed: true }
    : { content: buffer, compressed: false };
}

export function decompressBuffer(buffer) {
  return zlib.gunzipSync(buffer);
}
