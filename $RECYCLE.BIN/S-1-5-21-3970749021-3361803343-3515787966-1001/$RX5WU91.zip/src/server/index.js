import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { exec } from 'node:child_process';
import chalk from 'chalk';
import { loadConfig, getDbName } from '../config.js';
import { connect, disconnect } from '../db.js';
import { useCommand } from '../commands/use.js';
import { uploadCommand } from '../commands/upload.js';
import { downloadCommand } from '../commands/download.js';
import { listCommand } from '../commands/list.js';
import { deleteCommand } from '../commands/delete.js';
import { statusCommand } from '../commands/status.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, 'public');

function openBrowser(url) {
  const cmd =
    process.platform === 'win32'
      ? `start "" "${url}"`
      : process.platform === 'darwin'
        ? `open "${url}"`
        : `xdg-open "${url}"`;
  exec(cmd, () => {
    // Best-effort only — if it fails, the user still has the URL printed
    // to the terminal to open manually.
  });
}

function buildApp(dbHandle) {
  const app = express();
  app.use(express.json());

  // Simple pub-sub so /api/events (SSE) subscribers get live progress
  // pushed to them while /api/upload or /api/download are running. Writing
  // to a client whose connection dropped uncleanly can throw — an
  // unhandled error on a response stream crashes the whole process, so
  // every write is isolated in its own try/catch and bad clients are
  // dropped rather than allowed to take the server down.
  const sseClients = new Set();
  function broadcast(event) {
    const payload = `data: ${JSON.stringify(event)}\n\n`;
    for (const res of sseClients) {
      try {
        res.write(payload);
      } catch {
        sseClients.delete(res);
      }
    }
  }

  // This is a single-user local tool — one operation at a time keeps the
  // model (and the log panel) simple.
  let busy = false;
  function withLock(handler) {
    return async (req, res) => {
      if (busy) {
        res.status(409).json({ error: 'Another operation is already running. Please wait for it to finish.' });
        return;
      }
      busy = true;
      try {
        await handler(req, res);
      } catch (err) {
        res.status(500).json({ error: err.message });
      } finally {
        busy = false;
      }
    };
  }

  function ctx() {
    return { config: loadConfig(), ...dbHandle };
  }

  app.get('/api/events', (req, res) => {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });
    res.write('\n');
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
    res.on('error', () => sseClients.delete(res));
  });

  app.get('/api/state', (req, res) => {
    const config = loadConfig();
    res.json({ activeFolder: config.activeFolder ?? null, dbName: getDbName(config), busy });
  });

  app.post('/api/active-folder', async (req, res) => {
    const folderPath = req.body?.path;
    if (!folderPath) {
      res.status(400).json({ error: 'path is required' });
      return;
    }
    try {
      const result = await useCommand(folderPath);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // Lets the UI walk the local filesystem (directories only) so the user
  // can pick a folder without typing an absolute path from scratch.
  app.get('/api/browse', (req, res) => {
    const targetRaw = req.query.path ? String(req.query.path) : os.homedir();
    const target = path.resolve(targetRaw);

    let entries;
    try {
      entries = fs
        .readdirSync(target, { withFileTypes: true })
        .filter((e) => e.isDirectory() && !e.name.startsWith('.'))
        .map((e) => ({ name: e.name, path: path.join(target, e.name) }))
        .sort((a, b) => a.name.localeCompare(b.name));
    } catch (err) {
      res.status(400).json({ error: `Cannot read directory: ${err.message}` });
      return;
    }

    const parent = path.dirname(target);
    res.json({ path: target, parent: parent === target ? null : parent, entries });
  });

  app.get(
    '/api/folders',
    withLock(async (req, res) => {
      const result = await listCommand(ctx());
      res.json(result);
    })
  );

  app.get(
    '/api/status',
    withLock(async (req, res) => {
      const result = await statusCommand(ctx());
      res.json(result);
    })
  );

  app.post(
    '/api/upload',
    withLock(async (req, res) => {
      broadcast({ kind: 'job-start', job: 'upload' });
      const summary = await uploadCommand(ctx(), req.body?.folder, (event) => broadcast({ ...event, job: 'upload' }));
      broadcast({ kind: 'job-end', job: 'upload' });
      res.json(summary);
    })
  );

  app.post(
    '/api/download',
    withLock(async (req, res) => {
      broadcast({ kind: 'job-start', job: 'download' });
      const summary = await downloadCommand(ctx(), req.body?.dest, (event) =>
        broadcast({ ...event, job: 'download' })
      );
      broadcast({ kind: 'job-end', job: 'download' });
      res.json(summary);
    })
  );

  app.delete(
    '/api/folders/:name',
    withLock(async (req, res) => {
      const result = await deleteCommand(ctx(), req.params.name);
      res.json(result);
    })
  );

  app.use(express.static(PUBLIC_DIR));

  // Fallback error handler for anything thrown outside withLock (e.g. sync
  // errors in /api/active-folder or /api/browse handlers above).
  app.use((err, req, res, next) => {
    res.status(500).json({ error: err.message });
  });

  return app;
}

export async function startServer({ port = 4478, open: shouldOpen = true } = {}) {
  // Without these, an error thrown outside of Express's request handling
  // (e.g. an unawaited rejected promise) kills the process silently and
  // every open browser tab just sees "Failed to fetch" with no clue why.
  process.on('uncaughtException', (err) => {
    console.error(chalk.red('✖ Unexpected error:'), err.stack || err.message);
  });
  process.on('unhandledRejection', (err) => {
    console.error(chalk.red('✖ Unexpected rejected promise:'), err?.stack || err);
  });

  const config = loadConfig();
  const dbHandle = await connect(config);
  const app = buildApp(dbHandle);

  const server = app.listen(port, '127.0.0.1', () => {
    const url = `http://127.0.0.1:${port}`;
    console.log(chalk.green('✔'), `Local UI running at ${chalk.bold(url)}`);
    console.log(chalk.dim('  Bound to 127.0.0.1 only — not reachable from other devices. Press Ctrl+C to stop.'));
    if (shouldOpen) openBrowser(url);
  });

  const shutdown = async () => {
    console.log('\nShutting down...');
    server.close();
    await disconnect();
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}
