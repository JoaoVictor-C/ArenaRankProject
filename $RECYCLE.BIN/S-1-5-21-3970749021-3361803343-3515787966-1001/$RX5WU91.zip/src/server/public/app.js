function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / Math.pow(1024, i);
  return `${value.toFixed(i === 0 ? 0 : 2)} ${units[i]}`;
}

async function fetchJSON(url, opts) {
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

const els = {
  banner: document.querySelector('#banner'),
  dbName: document.querySelector('#db-name'),
  activeFolderName: document.querySelector('#active-folder-name'),
  activeFolderPath: document.querySelector('#active-folder-path'),
  usageBarFill: document.querySelector('#usage-bar-fill'),
  usageLabel: document.querySelector('#usage-label'),
  foldersBody: document.querySelector('#folders-body'),
  foldersEmpty: document.querySelector('#folders-empty'),
  refreshFoldersBtn: document.querySelector('#refresh-folders-btn'),
  log: document.querySelector('#log'),
  uploadBtn: document.querySelector('#upload-btn'),
  downloadBtn: document.querySelector('#download-btn'),
  statusBtn: document.querySelector('#status-btn'),
  chooseFolderBtn: document.querySelector('#choose-folder-btn'),
  browserModal: document.querySelector('#browser-modal'),
  browserPath: document.querySelector('#browser-path'),
  browserList: document.querySelector('#browser-list'),
  browserUp: document.querySelector('#browser-up'),
  browserSelect: document.querySelector('#browser-select'),
  browserClose: document.querySelector('#browser-close'),
  browserGoInput: document.querySelector('#browser-go-input'),
  browserGoBtn: document.querySelector('#browser-go-btn'),
};

let showErrorTimer;
function showError(message) {
  els.banner.textContent = message;
  els.banner.classList.add('visible');
  clearTimeout(showErrorTimer);
  showErrorTimer = setTimeout(() => els.banner.classList.remove('visible'), 6000);
}

function logLine(text, cls = '') {
  const line = document.createElement('div');
  line.className = `log-line ${cls}`.trim();
  line.textContent = text;
  els.log.appendChild(line);
  els.log.scrollTop = els.log.scrollHeight;
}

function setBusy(busy) {
  for (const btn of [els.uploadBtn, els.downloadBtn, els.statusBtn, els.chooseFolderBtn]) {
    btn.disabled = busy;
  }
}

async function refreshState() {
  const data = await fetchJSON('/api/state');
  els.dbName.textContent = `db: ${data.dbName}`;
  if (data.activeFolder) {
    els.activeFolderName.textContent = data.activeFolder.name;
    els.activeFolderPath.textContent = data.activeFolder.path;
  } else {
    els.activeFolderName.textContent = 'No folder selected';
    els.activeFolderPath.textContent = 'Click "Change…" to pick one.';
  }
  return data;
}

async function refreshFolders() {
  const [data, state] = await Promise.all([fetchJSON('/api/folders'), fetchJSON('/api/state')]);
  const activeName = state.activeFolder?.name;

  els.foldersBody.innerHTML = '';
  els.foldersEmpty.classList.toggle('visible', data.folders.length === 0);

  for (const f of data.folders) {
    const tr = document.createElement('tr');

    const nameTd = document.createElement('td');
    nameTd.textContent = f.name;
    if (f.name === activeName) {
      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.textContent = 'active';
      nameTd.appendChild(badge);
    }

    const countTd = document.createElement('td');
    countTd.textContent = f.count;

    const sizeTd = document.createElement('td');
    sizeTd.textContent = formatBytes(f.totalBytes);

    const actionTd = document.createElement('td');
    const delBtn = document.createElement('button');
    delBtn.className = 'btn danger';
    delBtn.textContent = 'Delete';
    delBtn.addEventListener('click', () => deleteFolder(f.name));
    actionTd.appendChild(delBtn);

    tr.append(nameTd, countTd, sizeTd, actionTd);
    els.foldersBody.appendChild(tr);
  }

  const pct = data.limitBytes ? (data.usedBytes / data.limitBytes) * 100 : 0;
  els.usageBarFill.style.width = `${Math.min(pct, 100)}%`;
  els.usageLabel.textContent = `${formatBytes(data.usedBytes)} / ${formatBytes(data.limitBytes)} (${pct.toFixed(1)}%)`;
}

async function deleteFolder(name) {
  if (!confirm(`Delete all data for folder "${name}"? This cannot be undone.`)) return;
  try {
    setBusy(true);
    const result = await fetchJSON(`/api/folders/${encodeURIComponent(name)}`, { method: 'DELETE' });
    logLine(`Deleted ${result.deletedCount} file record(s) and ${result.gridfsDeleted} GridFS blob(s) for "${name}".`, 'ok');
    await refreshFolders();
  } catch (err) {
    showError(err.message);
  } finally {
    setBusy(false);
  }
}

async function runUpload() {
  els.log.innerHTML = '';
  logLine('Starting upload…');
  try {
    setBusy(true);
    const summary = await fetchJSON('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    });
    logLine(
      `Done. Uploaded ${summary.uploaded}, skipped ${summary.skipped}, failed ${summary.failed}.`,
      summary.failed ? 'warn' : 'ok'
    );
    await refreshFolders();
  } catch (err) {
    showError(err.message);
    logLine(`Error: ${err.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

async function runDownload() {
  els.log.innerHTML = '';
  logLine('Starting download…');
  try {
    setBusy(true);
    const summary = await fetchJSON('/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    });
    logLine(
      `Done. Downloaded ${summary.downloaded}, skipped ${summary.skipped}, failed ${summary.failed}.`,
      summary.failed ? 'warn' : 'ok'
    );
  } catch (err) {
    showError(err.message);
    logLine(`Error: ${err.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

async function runStatus() {
  els.log.innerHTML = '';
  logLine('Checking status…');
  try {
    setBusy(true);
    const data = await fetchJSON('/api/status');
    for (const c of data.changes) {
      logLine(`${c.kind === 'new' ? 'new     ' : 'modified'} ${c.path}`, c.kind === 'new' ? 'ok' : 'warn');
    }
    for (const rel of data.missingLocally) {
      logLine(`missing  ${rel} (in DB, not on disk)`, 'warn');
    }
    logLine(
      `New: ${data.counts.added}  Modified: ${data.counts.modified}  Unchanged: ${data.counts.unchanged}  Missing locally: ${data.counts.missingLocally}`
    );
  } catch (err) {
    showError(err.message);
    logLine(`Error: ${err.message}`, 'error');
  } finally {
    setBusy(false);
  }
}

els.uploadBtn.addEventListener('click', runUpload);
els.downloadBtn.addEventListener('click', runDownload);
els.statusBtn.addEventListener('click', runStatus);
els.refreshFoldersBtn.addEventListener('click', () => refreshFolders().catch((err) => showError(err.message)));

// --- Folder browser modal ---

let browserCurrentPath = null;

async function navigateBrowser(targetPath) {
  const url = targetPath ? `/api/browse?path=${encodeURIComponent(targetPath)}` : '/api/browse';
  try {
    const data = await fetchJSON(url);
    browserCurrentPath = data.path;
    els.browserPath.textContent = data.path;
    els.browserGoInput.value = data.path;
    els.browserUp.disabled = !data.parent;
    els.browserUp.dataset.parent = data.parent || '';

    els.browserList.innerHTML = '';
    for (const entry of data.entries) {
      const li = document.createElement('li');
      li.textContent = entry.name;
      li.addEventListener('click', () => navigateBrowser(entry.path));
      els.browserList.appendChild(li);
    }
  } catch (err) {
    showError(err.message);
  }
}

els.chooseFolderBtn.addEventListener('click', () => {
  els.browserModal.classList.add('visible');
  navigateBrowser(browserCurrentPath);
});
els.browserClose.addEventListener('click', () => els.browserModal.classList.remove('visible'));
els.browserModal.addEventListener('click', (e) => {
  if (e.target === els.browserModal) els.browserModal.classList.remove('visible');
});
els.browserUp.addEventListener('click', () => {
  if (els.browserUp.dataset.parent) navigateBrowser(els.browserUp.dataset.parent);
});
els.browserGoBtn.addEventListener('click', () => navigateBrowser(els.browserGoInput.value));
els.browserGoInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') navigateBrowser(els.browserGoInput.value);
});
els.browserSelect.addEventListener('click', async () => {
  try {
    await fetchJSON('/api/active-folder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: browserCurrentPath }),
    });
    els.browserModal.classList.remove('visible');
    await refreshState();
    await refreshFolders();
  } catch (err) {
    showError(err.message);
  }
});

// --- Live progress via SSE ---

const events = new EventSource('/api/events');
events.onmessage = (e) => {
  const data = JSON.parse(e.data);
  if (data.kind !== 'file') return;

  let sizeInfo = '';
  if (data.action === 'upload' || data.action === 'download') {
    const original = data.originalBytes ?? 0;
    sizeInfo = data.compressed ? `${formatBytes(original)} -> ${formatBytes(data.storedBytes)} gzip` : formatBytes(original);
  }

  const cls = data.action === 'error' ? 'error' : data.action === 'skip' ? 'dim' : 'ok';
  const message = data.action === 'error' ? data.message : sizeInfo ? `(${sizeInfo})` : '';
  logLine(`${data.action.padEnd(8)} ${data.path} ${message}`, cls);
};
events.onerror = () => {
  // The browser's EventSource auto-reconnects; nothing to do here beyond
  // not spamming the log on every transient blip.
};

// --- Initial load ---

refreshState().catch((err) => showError(err.message));
refreshFolders().catch((err) => showError(err.message));
